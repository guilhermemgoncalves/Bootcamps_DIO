package br.com.globallabs.exemplomaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroExemploMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
