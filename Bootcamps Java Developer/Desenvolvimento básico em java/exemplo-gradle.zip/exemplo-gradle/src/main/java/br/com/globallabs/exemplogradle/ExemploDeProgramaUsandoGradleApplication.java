package br.com.globallabs.exemplogradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploDeProgramaUsandoGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploDeProgramaUsandoGradleApplication.class, args);
	}

}
